from pydantic import BaseModel

class SiteUpdateIn(BaseModel):
    project_id: int = 1
    source: str
    text: str

class ActivityOut(BaseModel):
    id: int
    code: str
    level: str
    name: str
    planned_start: str | None
    planned_finish: str | None
    actual_start: str | None
    actual_finish: str | None
    planned_progress: float
    actual_progress: float
    status: str

    class Config:
        from_attributes = True
