from sqlalchemy import Column, Integer, String, Float, Text, ForeignKey
from app.database import Base

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    overall_planned = Column(Float, default=0)
    overall_actual = Column(Float, default=0)

class Activity(Base):
    __tablename__ = "activities"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    code = Column(String, unique=True, nullable=False)
    level = Column(String, default="L6")
    name = Column(String, nullable=False)
    planned_start = Column(String)
    planned_finish = Column(String)
    actual_start = Column(String)
    actual_finish = Column(String)
    planned_progress = Column(Float, default=0)
    actual_progress = Column(Float, default=0)
    status = Column(String, default="Planned")

class Dependency(Base):
    __tablename__ = "dependencies"
    id = Column(Integer, primary_key=True)
    predecessor = Column(String, nullable=False)
    successor = Column(String, nullable=False)

class SiteUpdate(Base):
    __tablename__ = "site_updates"
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    source = Column(String, nullable=False)
    text = Column(Text, nullable=False)
    extracted_activity = Column(String)
    extracted_progress = Column(Float)
    issue = Column(String)
    confidence = Column(Float, default=0)
    match_status = Column(String, default="Pending")
