from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine
from app.seed import seed_database
from app.routes import projects, activities, site_updates, ai, uploads

Base.metadata.create_all(bind=engine)
seed_database()

app = FastAPI(title="INFRASYNC AI API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projects.router, prefix="/api/projects", tags=["Projects"])
app.include_router(activities.router, prefix="/api/activities", tags=["Activities"])
app.include_router(site_updates.router, prefix="/api/site-updates", tags=["Site Updates"])
app.include_router(ai.router, prefix="/api/ai", tags=["AI"])
app.include_router(uploads.router, prefix="/api/uploads", tags=["Uploads"])

@app.get("/")
def root():
    return {"name": "INFRASYNC AI", "status": "running"}

@app.get("/api/health")
def health():
    return {"status": "ok"}
