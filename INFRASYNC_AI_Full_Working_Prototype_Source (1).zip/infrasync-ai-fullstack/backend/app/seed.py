from app.database import SessionLocal
from app.models import Project, Activity, Dependency

def seed_database():
    db = SessionLocal()
    try:
        if db.query(Project).first():
            return
        project = Project(
            name="NER Infrastructure Pipeline Project",
            overall_planned=78,
            overall_actual=74,
        )
        db.add(project)
        db.flush()

        rows = [
            ("P-101","L6","Prepare Trench","01 Sep","05 Sep",None,"05 Sep",100,100,"Completed"),
            ("P-102","L6","Install Pipeline Section P-102","10 Sep","15 Sep","12 Sep","17 Sep",100,100,"Delayed"),
            ("P-103","L6","Welding","16 Sep","20 Sep",None,None,80,65,"At Risk"),
            ("P-104","L6","Inspection","21 Sep","23 Sep",None,None,50,20,"At Risk"),
            ("P-105","L6","Backfilling","24 Sep","28 Sep",None,None,0,0,"Planned"),
            ("P-106","L6","Site Restoration","29 Sep","02 Oct",None,None,0,0,"Planned"),
            ("P-211","L6","Valve Testing","03 Oct","05 Oct",None,None,30,0,"Missing Update"),
        ]
        for r in rows:
            db.add(Activity(project_id=project.id, code=r[0], level=r[1], name=r[2],
                            planned_start=r[3], planned_finish=r[4], actual_start=r[5],
                            actual_finish=r[6], planned_progress=r[7], actual_progress=r[8],
                            status=r[9]))
        deps = [("P-101","P-102"),("P-102","P-103"),("P-103","P-104"),("P-104","P-105"),("P-105","P-106")]
        for a,b in deps:
            db.add(Dependency(predecessor=a, successor=b))
        db.commit()
    finally:
        db.close()
