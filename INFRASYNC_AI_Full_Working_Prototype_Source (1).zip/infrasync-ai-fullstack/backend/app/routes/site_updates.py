from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import SiteUpdate, Activity
from app.schemas import SiteUpdateIn
from app.ai_engine import extract, status_from_progress

router = APIRouter()

@router.post("")
def create_update(payload: SiteUpdateIn, db: Session = Depends(get_db)):
    activities = db.query(Activity).filter(Activity.project_id == payload.project_id).all()
    result = extract(payload.text, activities)
    activity = result["activity"]

    su = SiteUpdate(
        project_id=payload.project_id,
        source=payload.source,
        text=payload.text,
        extracted_activity=activity.code if activity else None,
        extracted_progress=result["progress"],
        issue=result["issue"],
        confidence=result["confidence"] * 100,
        match_status="Matched" if activity else "Review"
    )
    db.add(su)

    if activity and result["progress"] is not None:
        activity.actual_progress = result["progress"]
        activity.status = status_from_progress(activity.planned_progress, activity.actual_progress)

    db.commit()
    db.refresh(su)

    return {
        "id": su.id,
        "extracted": {
            "activity_id": activity.code if activity else None,
            "work_type": activity.name if activity else None,
            "progress": result["progress"],
            "issue": result["issue"]
        },
        "match": {
            "activity": activity.name if activity else None,
            "level": activity.level if activity else None,
            "confidence": round(result["confidence"] * 100)
        },
        "status": activity.status if activity else "Review"
    }

@router.get("")
def list_updates(project_id: int = 1, db: Session = Depends(get_db)):
    return db.query(SiteUpdate).filter(SiteUpdate.project_id == project_id).order_by(SiteUpdate.id.desc()).all()
