from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Activity, Dependency
from app.ai_engine import extract

router = APIRouter()

@router.post("/match-activity")
def match_activity(text: str, project_id: int = 1, db: Session = Depends(get_db)):
    acts = db.query(Activity).filter(Activity.project_id == project_id).all()
    r = extract(text, acts)
    a = r["activity"]
    return {
        "activity_id": a.code if a else None,
        "activity_name": a.name if a else None,
        "level": a.level if a else None,
        "progress": r["progress"],
        "issue": r["issue"],
        "confidence": round(r["confidence"] * 100)
    }

@router.get("/delay-analysis")
def delay_analysis(project_id: int = 1, db: Session = Depends(get_db)):
    acts = db.query(Activity).filter(Activity.project_id == project_id).all()
    result = []
    for a in acts:
        variance = a.actual_progress - a.planned_progress
        if variance < -10:
            risk = "HIGH"
        elif variance < 0:
            risk = "MEDIUM"
        else:
            risk = "LOW"
        if risk != "LOW":
            result.append({
                "activity": a.code,
                "name": a.name,
                "planned": a.planned_progress,
                "actual": a.actual_progress,
                "variance": variance,
                "risk": risk
            })
    return result

@router.get("/dependencies")
def dependencies(db: Session = Depends(get_db)):
    deps = db.query(Dependency).all()
    return [{"source": d.predecessor, "target": d.successor} for d in deps]
