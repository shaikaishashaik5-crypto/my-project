from fastapi import APIRouter, UploadFile, File
from pathlib import Path
import uuid

router = APIRouter()
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

@router.post("")
async def upload_file(file: UploadFile = File(...)):
    safe = f"{uuid.uuid4().hex}_{Path(file.filename).name}"
    path = UPLOAD_DIR / safe
    path.write_bytes(await file.read())
    return {"filename": file.filename, "stored_as": safe, "message": "File received successfully"}
