from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Activity

router = APIRouter()

@router.get("")
def list_activities(project_id: int = 1, db: Session = Depends(get_db)):
    return db.query(Activity).filter(Activity.project_id == project_id).all()

@router.get("/{code}")
def get_activity(code: str, db: Session = Depends(get_db)):
    return db.query(Activity).filter(Activity.code == code).first()
