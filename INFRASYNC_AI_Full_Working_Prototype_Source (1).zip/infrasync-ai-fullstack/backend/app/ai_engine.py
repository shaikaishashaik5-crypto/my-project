import re
from difflib import SequenceMatcher

def extract(text: str, activities):
    t = text.lower()
    activity = None

    # Strong identifier match first.
    for a in activities:
        if a.code.lower() in t or a.code.replace("-", "").lower() in t.replace("-", ""):
            activity = a
            break

    # Otherwise compare activity-name tokens.
    if activity is None:
        best, score = None, 0
        for a in activities:
            s = SequenceMatcher(None, t, a.name.lower()).ratio()
            tokens = [x for x in re.findall(r"[a-z0-9]+", a.name.lower()) if len(x) > 3]
            overlap = sum(x in t for x in tokens)
            s += overlap * 0.08
            if s > score:
                score, best = s, a
        activity = best

    progress = None
    m = re.search(r"(\d+(?:\.\d+)?)\s*%", text)
    if m:
        progress = float(m.group(1))
    elif "completed" in t or "finished" in t or "done" in t:
        progress = 100.0

    issue = None
    if "material" in t and ("late" in t or "delay" in t):
        issue = "Material arrival delay"
    elif "delay" in t:
        issue = "Reported delay"

    confidence = 0
    if activity:
        confidence = 0.97 if activity.code.lower() in t else 0.88
        if progress is not None:
            confidence += 0.02
        confidence = min(confidence, 0.99)

    return {
        "activity": activity,
        "progress": progress,
        "issue": issue,
        "confidence": confidence
    }

def status_from_progress(planned, actual):
    variance = actual - planned
    if variance >= 0:
        return "On Track"
    if variance >= -10:
        return "At Risk"
    return "Delayed"
