# INFRASYNC AI — Full Working Prototype

A full-stack version of the uploaded BuildSync/INFRASYNC prototype.

## Stack
- Frontend: React + Vite + plain CSS
- Backend: FastAPI + SQLite + SQLAlchemy
- AI demo engine: deterministic NLP/rule matching (no API key required)
- File upload: FastAPI multipart upload
- Dependency impact: graph data returned by API

## Run

### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal.

The frontend expects the backend at `http://localhost:8000`.
