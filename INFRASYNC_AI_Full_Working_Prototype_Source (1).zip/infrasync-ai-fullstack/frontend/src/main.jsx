import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import {BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer} from "recharts";
import "./styles.css";

const API="http://localhost:8000/api";

function App(){
  const [page,setPage]=useState("dashboard");
  const [project,setProject]=useState(null);
  const [activities,setActivities]=useState([]);
  const [updates,setUpdates]=useState([]);
  const [text,setText]=useState("P-102 pipeline installation completed today. Work started late because material arrived late.");
  const [source,setSource]=useState("Text message");
  const [result,setResult]=useState(null);
  const [toast,setToast]=useState("");

  const load=async()=>{
    const p=await fetch(API+"/projects/1").then(r=>r.json());
    setProject(p.project); setActivities(p.activities);
    setUpdates(await fetch(API+"/site-updates?project_id=1").then(r=>r.json()));
  };
  useEffect(()=>{load()},[]);
  const notify=(s)=>{setToast(s);setTimeout(()=>setToast(""),2500)}
  const processAI=async()=>{
    const r=await fetch(API+"/site-updates",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({project_id:1,source,text})}).then(r=>r.json());
    setResult(r); await load(); notify("AI processed the site update.");
  };

  const nav=[
    ["dashboard","📊 Dashboard"],["command","🎯 Command Center"],["schedule","📅 Project Schedule"],
    ["capture","📥 Site Data Capture"],["documents","📄 Reports & Documents"],["matching","🔗 AI Schedule Matching"],
    ["progress","📈 Plan vs Actual"],["risk","⚠️ Delay & Risk"],["dependencies","🕸️ Dependencies"],
    ["resources","👷 Resources"],["reports","📑 Reports"],["audit","🧾 Audit Trail"],["settings","⚙️ Settings"]
  ];

  const Page=()=>{
    if(page==="dashboard") return <Dashboard project={project} activities={activities} nav={setPage}/>;
    if(page==="schedule") return <Schedule activities={activities}/>;
    if(page==="capture") return <Capture {...{source,setSource,text,setText,processAI,result,notify}}/>;
    if(page==="matching") return <Matching result={result}/>;
    if(page==="progress") return <Progress activities={activities}/>;
    if(page==="risk") return <Risk activities={activities}/>;
    if(page==="dependencies") return <Dependencies/>;
    if(page==="command") return <Command nav={setPage}/>;
    if(page==="documents") return <Documents/>;
    if(page==="resources") return <Resources/>;
    if(page==="reports") return <Reports activities={activities}/>;
    if(page==="audit") return <Audit updates={updates}/>;
    return <Settings/>;
  };

  return <><header className="top"><div className="brand"><div className="logo">🤖</div><div><b>INFRASYNC AI</b><small>Planning-to-Execution Bridge</small></div></div><div>Project Control Room <span className="avatar">PC</span></div></header>
  <div className="shell"><nav className="side">{nav.map(([id,label])=><button key={id} className={page===id?"active":""} onClick={()=>setPage(id)}>{label}</button>)}</nav>
  <main className="content"><Page/></main></div><div className="toast" style={{display:toast?"block":"none"}}>{toast}</div></>
}

const Title=({title,sub,children})=><div className="title"><div><h1>{title}</h1><p>{sub}</p></div>{children}</div>;
const Card=({children})=><div className="card">{children}</div>;
const Panel=({children})=><div className="panel">{children}</div>;

function Dashboard({project,activities,nav}){
 const delayed=activities.filter(a=>a.status==="Delayed").length;
 const risk=activities.filter(a=>a.status==="At Risk").length;
 return <><Title title="Project Dashboard" sub="One view connecting planned schedule with actual site progress."/>
 <div className="grid g4"><Card><label>TOTAL ACTIVITIES</label><strong className="num blue">{activities.length}</strong><small>L5/L6 schedule activities</small></Card><Card><label>COMPLETED</label><strong className="num green">{activities.filter(a=>a.actual_progress>=100).length}</strong><small>Based on linked updates</small></Card><Card><label>AT RISK</label><strong className="num orange">{risk}</strong><small>Needs project-manager review</small></Card><Card><label>DELAYED</label><strong className="num red">{delayed}</strong><small>Detected from linked updates</small></Card></div>
 <div className="grid g2 mt"><Panel><h2>🔄 End-to-End AI Pipeline</h2><div className="flow"><span>1. CAPTURE<br/><small>Voice • Text • Reports • Photos</small></span>→<span>2. EXTRACT<br/><small>Activity • Date • Status • Issue</small></span>→<span>3. MATCH<br/><small>Correct L5/L6 activity</small></span>→<span>4. ANALYZE<br/><small>Plan vs actual</small></span>→<span>5. IMPACT<br/><small>Delay • Risk • Dependencies</small></span></div></Panel>
 <Panel><h2>🚨 Latest AI Alert</h2><div className="alert danger"><b>P-102 — Pipeline Installation</b><br/>2-day delay. Reported reason: material arrival delay.</div><button className="btn" onClick={()=>nav("risk")}>Open Risk Analysis →</button></Panel></div>
 <Panel><h2>Project Progress</h2><div className="kpi"><span>Overall planned progress</span><b>{project?.overall_planned ?? 78}%</b></div><div className="progress"><span style={{width:`${project?.overall_planned??78}%`}}/></div><div className="kpi"><span>Actual reported progress</span><b>{project?.overall_actual ?? 74}%</b></div><div className="progress"><span style={{width:`${project?.overall_actual??74}%`}}/></div></Panel></>
}

function Schedule({activities}){return <><Title title="📅 Project Schedule" sub="Structured project plan used as the matching backbone."/><Panel><table><thead><tr><th>ID</th><th>Level</th><th>Activity</th><th>Start</th><th>Finish</th><th>Planned</th><th>Actual</th><th>Status</th></tr></thead><tbody>{activities.map(a=><tr key={a.code}><td>{a.code}</td><td>{a.level}</td><td>{a.name}</td><td>{a.planned_start}</td><td>{a.planned_finish}</td><td>{a.planned_progress}%</td><td>{a.actual_progress}%</td><td><span className={"pill "+pill(a.status)}>{a.status}</span></td></tr>)}</tbody></table></Panel></>}
const pill=s=>s==="Delayed"?"pred":s==="At Risk"||s==="Missing Update"?"porange":"pgreen";

function Capture({source,setSource,text,setText,processAI,result,notify}){return <><Title title="📥 Site Data Capture" sub="Bring scattered site information into one structured workflow."/><div className="grid g2"><Panel><h2>Submit Site Update</h2><label>Input source</label><select value={source} onChange={e=>setSource(e.target.value)}><option>Voice transcript</option><option>Text message</option><option>Daily report</option><option>Excel / spreadsheet</option><option>Photo observation</option></select><label>Site update</label><textarea rows="7" value={text} onChange={e=>setText(e.target.value)}/><button className="btn" onClick={processAI}>🤖 Process with AI</button></Panel><Panel><h2>Accepted Data Types</h2><div className="upload">📤<br/><b>Construction reports / spreadsheets / photos</b><br/><small>Choose a file to send to the backend.</small><input id="file" type="file" onChange={async e=>{if(!e.target.files[0])return;const fd=new FormData();fd.append("file",e.target.files[0]);await fetch(API+"/uploads",{method:"POST",body:fd});notify("File received by backend.")}}/><label className="filebtn" htmlFor="file">Choose File</label></div></Panel></div>{result&&<Panel><h2>🤖 AI Processing Result</h2><div className="result"><b>Extracted:</b> {result.extracted.activity_id} • {result.extracted.work_type} • Progress {result.extracted.progress ?? "not stated"}% • {result.extracted.issue||"No issue extracted"}</div><div className="grid g2 mt"><div><h3>Matched Schedule</h3><p>{result.match.level} — {result.match.activity}</p><span className="pill pgreen">MATCHED</span></div><div><h3>Confidence</h3><div className="confidence">{result.match.confidence}%</div><div className="progress"><span style={{width:`${result.match.confidence}%`}}/></div></div></Panel>}</>}

function Matching({result}){return <><Title title="🔗 AI Schedule Matching" sub="Connect site wording to the correct scheduled activity."/><Panel><h2>Latest Incoming Site Statement</h2><div className="result">{result ? "Processed site statement is shown below." : "Submit a site update from Site Data Capture to see a live match."}</div>{result&&<div className="grid g2 mt"><div><h3>AI EXTRACTED</h3><div className="kpi"><span>Activity ID</span><b>{result.extracted.activity_id}</b></div><div className="kpi"><span>Work type</span><b>{result.extracted.work_type}</b></div><div className="kpi"><span>Progress</span><b>{result.extracted.progress ?? "—"}%</b></div><div className="kpi"><span>Issue</span><b>{result.extracted.issue||"None"}</b></div></div><div><h3>MATCH RESULT</h3><p>{result.match.level} — {result.match.activity}</p><div className="confidence">{result.match.confidence}%</div><small>AI confidence</small><div className="progress"><span style={{width:`${result.match.confidence}%`}}/></div></div></div>}</Panel></>}

function Progress({activities}){let a=activities.find(x=>x.code==="P-102")||activities[0];return <><Title title="📈 Plan vs Actual" sub="Compare schedule values with linked site updates."/><Panel><h2>{a?.code} — {a?.name}</h2><div className="grid g2"><table><tbody><tr><th>Parameter</th><th>Planned</th><th>Actual</th></tr><tr><td>Start</td><td>{a?.planned_start}</td><td>{a?.actual_start||"—"}</td></tr><tr><td>Finish</td><td>{a?.planned_finish}</td><td>{a?.actual_finish||"—"}</td></tr><tr><td>Progress</td><td>{a?.planned_progress}%</td><td>{a?.actual_progress}%</td></tr><tr><td>Status</td><td>Planned</td><td>{a?.status}</td></tr></tbody></table><div><p>PROGRESS COMPARISON</p><div className="bar plan" style={{width:`${a?.planned_progress||0}%`}}>Planned {a?.planned_progress}%</div><div className="bar actual" style={{width:`${a?.actual_progress||0}%`}}>Actual {a?.actual_progress}%</div><div className="alert danger"><b>{Math.max(0,(a?.planned_progress||0)-(a?.actual_progress||0))}% progress variance</b><br/>Review the linked site evidence.</div></div></div></Panel></>}

function Risk({activities}){let risky=activities.filter(a=>a.status==="Delayed"||a.status==="At Risk"||a.status==="Missing Update");return <><Title title="⚠️ Delay & Risk Intelligence" sub="Prioritize activities needing human review."/><div className="grid g3"><Card><label>HIGH RISK</label><strong className="num red">{activities.filter(a=>a.status==="Delayed").length}</strong></Card><Card><label>MEDIUM RISK</label><strong className="num orange">{activities.filter(a=>a.status==="At Risk").length}</strong></Card><Card><label>ON TRACK</label><strong className="num green">{activities.filter(a=>a.status==="Completed").length}</strong></Card></div><Panel><table><thead><tr><th>Activity</th><th>Signal</th><th>Planned</th><th>Actual</th><th>Variance</th></tr></thead><tbody>{risky.map(a=><tr key={a.code}><td>{a.code} {a.name}</td><td><span className={"pill "+pill(a.status)}>{a.status}</span></td><td>{a.planned_progress}%</td><td>{a.actual_progress}%</td><td>{a.actual_progress-a.planned_progress}%</td></tr>)}</tbody></table></Panel></>}

function Dependencies(){const nodes=["P-101 Trenching ✓","P-102 Installation −2d","P-103 Welding ⚠","P-104 Inspection ⚠","P-105 Backfilling"];return <><Title title="🕸️ Dependency Impact" sub="Trace how one activity can affect downstream work."/><Panel><h2>Dependency Chain</h2><div className="flow">{nodes.map((n,i)=><React.Fragment key={n}><span className={i===1?"risknode":""}>{n}</span>{i<nodes.length-1&&" → "}</React.Fragment>)}</div><div className="alert warn mt"><b>AI impact insight:</b> P-102 delay is linked to downstream activities P-103 and P-104 for review. The system does not automatically alter the official schedule.</div></Panel></>}

const Command=({nav})=><><Title title="🎯 Project Command Center" sub="What needs attention right now?"/><div className="grid g3"><Panel><h2>🔴 Immediate Review</h2><div className="alert danger">Critical delay signals require review.</div><button className="btn red" onClick={()=>nav("risk")}>Review Delays</button></Panel><Panel><h2>🟠 Dependency Risk</h2><div className="alert warn">Downstream activities may be affected.</div><button className="btn" onClick={()=>nav("dependencies")}>Trace Impact</button></Panel><Panel><h2>🟢 Data Ready</h2><div className="alert ok">New site updates can be processed.</div><button className="btn green" onClick={()=>nav("capture")}>Process Update</button></Panel></div></>;
const Documents=()=> <><Title title="📄 Reports & Documents" sub="Site reports are converted into project information."/><Panel><table><thead><tr><th>Document</th><th>Source</th><th>Result</th></tr></thead><tbody><tr><td>Daily_Report_17Sep.pdf</td><td>Site Engineer</td><td><span className="pill pgreen">Matched</span></td></tr><tr><td>Pipeline_Update.xlsx</td><td>Planning Team</td><td><span className="pill pgreen">Matched</span></td></tr><tr><td>ZoneA_Photos.zip</td><td>Site Supervisor</td><td><span className="pill porange">Review</span></td></tr></tbody></table></Panel></>;
const Resources=()=> <><Title title="👷 Resource View" sub="Connect reported progress with project resources."/><Panel><table><thead><tr><th>Resource</th><th>Planned</th><th>Reported</th><th>Signal</th></tr></thead><tbody><tr><td>Pipeline Crew A</td><td>18</td><td>16</td><td>Normal</td></tr><tr><td>Welding Crew B</td><td>14</td><td>9</td><td>Review</td></tr><tr><td>Inspection Team</td><td>6</td><td>6</td><td>Full</td></tr></tbody></table></Panel></>;
const Reports=({activities})=> <><Title title="📑 Management Reports" sub="Project-control outputs from linked data."/><div className="grid g3"><Panel><h2>Daily Progress</h2><p>Activities: <b>{activities.length}</b></p><p>Linked to schedule: <b>{activities.filter(a=>a.actual_progress>0).length}</b></p></Panel><Panel><h2>Delay Summary</h2><p>Delayed: <b className="red">{activities.filter(a=>a.status==="Delayed").length}</b></p></Panel><Panel><h2>Audit Summary</h2><p>AI decisions are recorded through site updates.</p></Panel></div></>;
const Audit=({updates})=> <><Title title="🧾 Audit Trail" sub="Every extraction and match is traceable."/><Panel><table><thead><tr><th>ID</th><th>Source</th><th>Extracted Activity</th><th>Confidence</th><th>Status</th></tr></thead><tbody>{updates.map(u=><tr key={u.id}><td>{u.id}</td><td>{u.source}</td><td>{u.extracted_activity||"—"}</td><td>{u.confidence}%</td><td>{u.match_status}</td></tr>)}</tbody></table></Panel></>;
const Settings=()=> <><Title title="⚙️ Project Settings" sub="Prototype configuration."/><Panel><div className="grid g2"><div><label>Project Name</label><input defaultValue="NER Infrastructure Pipeline Project"/><label>Schedule Level</label><select defaultValue="L6"><option value="L6">L6 — Detailed Activity</option><option value="L5">L5 — Work Package</option></select></div><div><label>Confidence threshold</label><input defaultValue="85%"/><label>Human verification</label><select><option>Required for low-confidence matches</option><option>Required for every match</option></select></div></div></Panel></>;

createRoot(document.getElementById("root")).render(<App/>);
